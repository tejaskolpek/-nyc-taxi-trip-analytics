from matplotlib.pylab import *  # noqa: F401, F403
import matplotlib.pylab
__doc__ = matplotlib.pylab.__doc__
